//-------------------------------------------
// PointClass.cs (c) 2006 by Charles Petzold
//-------------------------------------------
class PointClass
{
    public int x, y;
}
