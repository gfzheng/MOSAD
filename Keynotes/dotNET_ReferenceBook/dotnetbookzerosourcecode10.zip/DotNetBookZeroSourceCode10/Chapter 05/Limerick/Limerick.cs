//-----------------------------------------
// Limerick.cs (c) 2006 by Charles Petzold
//-----------------------------------------
using System;

class Limerick
{
    static void Main()
    {
        string strLimerick =
            "There once was a coder named Otto\r\n" +
            "Who had a peculiar motto:\r\n" +
            "    \"The goto is king,\r\n" +
            "    To thee I sing!\"\r\n" +
            "Maybe that's why he's often quite blotto.\r\n";

        Console.WriteLine(strLimerick);
    }
}
