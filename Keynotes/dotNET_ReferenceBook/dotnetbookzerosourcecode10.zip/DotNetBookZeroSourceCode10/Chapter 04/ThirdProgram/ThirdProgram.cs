//---------------------------------------------
// ThirdProgram.cs (c) 2006 by Charles Petzold
//---------------------------------------------
using C = System.Console;

class ThirdProgram
{
    public static void Main()
    {
        C.WriteLine("Hello, Microsoft .NET Framework!");
    }
}
