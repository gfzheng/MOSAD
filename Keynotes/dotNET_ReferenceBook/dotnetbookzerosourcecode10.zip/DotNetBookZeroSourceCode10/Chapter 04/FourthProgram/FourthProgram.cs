//----------------------------------------------
// FourthProgram.cs (c) 2006 by Charles Petzold
//----------------------------------------------
using System;

namespace Petzold.FourthProgram
{
    class FourthProgram
    {
        public static void Main()
        {
            Console.WriteLine("Hello, Microsoft .NET Framework!");
        }
    }
}
