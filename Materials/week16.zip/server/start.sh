#!/bin/bash
export FLASK_ENV=development
python2 server.py || python server.py