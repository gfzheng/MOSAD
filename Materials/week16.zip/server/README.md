需要

+ python2
  + `cocos new` 的时候就有用到了
+ Flask
  + 可以通过 `pip install flask` / `sudo pip install flask` 来安装